﻿configuration Printerserver {
   param ($MachineName)

  Node $MachineName 
  {
      WindowsFeature Print-Server {
         Ensure               = 'Present'
         Name                 = 'Print-server'
         IncludeAllSubFeature = $true
      }
   }
}