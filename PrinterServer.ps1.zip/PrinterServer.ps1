﻿configuration PrinterServer {
   param ($MachineName)

  Node $MachineName 
  {
      WindowsFeature Print-Server {
         Ensure               = 'Present'
         Name                 = 'Print-Server'
      }
   }
}